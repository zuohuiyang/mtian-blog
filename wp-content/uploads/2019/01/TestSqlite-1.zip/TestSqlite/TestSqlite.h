// TestSqlite.cpp : Defines the entry point for the console application.
//


#include "sqlite3.h"

#define Table_Test		"TestTable"
#define Col_Idx			"Idx"
#define Col_Bin			"Bin"
#define Col_Len			"Len"
#define Col_Crc			"Crc32"


#define DB_DATA_NUM		100000
#define Test_Func_Run_Secondes	3

enum EMIOMode
{
	EMIOMode_None = 0,
	EMIOMode_Read,
	EMIOMode_Write,
};

enum EMReadResult
{
	EMRead_None = 0,
	EMRead_FindOK_CheckOK,
	EMRead_FindOK_CheckError,
	EMRead_NotFind,
	EMRead_Error_Busy,
	EMRead_Error_Misuse,
	EMRead_Error_Other,
	EMRead_Count,
};

enum EMWriteResult
{
	EMWrite_None = 0,
	EMWrite_OK,
	EMWrite_Error_Busy,
	EMWrite_Error_Other,
	EMWrite_Count,
};

class CTestSqlite
{
public:
	CTestSqlite();
	~CTestSqlite();

	void Test(
		EMIOMode emThrea1Mode,
		EMIOMode emThrea2Mode);


private:
	void TestProc(INT nMode);

	DWORD ThreadProc();
	static unsigned int __stdcall ThreadStartRoutine(void* pParam);

	EMReadResult Read();
	EMWriteResult Write();
	bool Init();

	bool InitDBFile();

	void Uninit();
	bool InitDBData();
	int GetCount();

private:
	ATL::CAtlString	m_strDBPath;
	sqlite3*	m_pDB;
	EMIOMode m_emThread1Mode;
	EMIOMode m_emThread2Mode;
	volatile DWORD m_dwThread1Started;
	volatile BOOL m_bTimeOut;

	CRITICAL_SECTION m_cs;
};

